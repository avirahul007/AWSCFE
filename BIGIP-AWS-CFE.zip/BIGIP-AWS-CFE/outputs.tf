output "cfe_s3_bucket_name" {
  value = aws_s3_bucket.cfe_state_bucket.bucket
}

output "bigip_iam_instance_profile" {
  value = aws_iam_instance_profile.bigip_profile.name
}

output "ec2_endpoint_dns" {
  value = aws_vpc_endpoint.ec2.dns_entry[0].dns_name
}