#Set you variables values in this file against each decleared variables

aws_region              = "eu-west-1"
vpc_id                  = "vpc-0123456789abcdef0"  ##example mention your own VPC ID
internal_subnet_ids     = ["subnet-0aaaaaaa", "subnet-0bbbbbbb"]  ##example mention your own SUBNET ID
route_table_ids         = ["rtb-01111111", "rtb-02222222"] ##example mention your own Route  ID for each BIGIP's and use common RT for all subnets (MGMT, EXTERNAL and INTERNAL)
bigip_sg_id             = "sg-0"  ##example mention your own Security Group ID which is applied on BIGIP

# BIG-IP Management IPs (Must be reachable from where you run Terraform)
bigip1_mgmt_ip          = "10.0.0.11"
bigip2_mgmt_ip          = "10.0.0.12"
bigip_admin_user        = "admin"
bigip_admin_password    = "YourSuperSecretPassword123!"

# CFE Specifics
vip_subnet_ranges       = ["10.0.10.0/24"]
bigip_external_self_ips = ["10.0.1.10", "10.0.1.11"]